import React, { Component } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Switch, Route} from 'react-router-dom';
import Login from './components/Login';
import Admin from './components/Admin';
import Logout from './components/Logout';

class App extends Component{
  render(){
return (
  <>
  <Switch>
      <Route exact path='/' component= {Login} />
      <Route path='/admin' component={Admin} />
      <Route path='/logout' component={Logout} />
      <Route component={Error} />
  </Switch>
  </>
);
}
}



export default App;