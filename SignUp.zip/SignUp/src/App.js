import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Switch, Route} from 'react-router-dom';
import Login from './components/Login';
import Admin from './components/Admin';
import Logout from './components/Logout';
import Signup from './components/Signup';
import Contact from './Contact';
import Error from './components/Error';

const App =(props) => {
return (
  <>
  <Switch>
      <Route exact path='/' component= {Login} />
      <Route path='/signup' component={Signup} />
      <Route path='/admin' component={Admin} />
      <Route path='/contact' component={Contact} />
      <Route path='/logout' component={Logout} />
      <Route component={Error} />
  </Switch>
  </>
);
}





export default App;