import React from 'react';
import { Link} from 'react-router-dom';


export default function Contact() {
    return (
        <>
          <nav className="navbar navbar-light" >
  <div className="container-fluid">
    <h1 className="navbar-brand">TechnoGiants</h1>
    <form className="d-flex">
    <Link to="/admin" className="btn btn-outline-success mr-2">Go Back</Link>
    </form>
  </div>
</nav> 
    <h1>Contact Us</h1> 
    </>
    )
}
