import React from 'react';
import { Link} from 'react-router-dom';

export default function Navbar() {



    return (
  <nav className="navbar navbar-light" >
  <div className="container-fluid">
    <h1 className="navbar-brand">TechnoGiants</h1>
    <form className="d-flex">
   <Link to="/" className="btn btn-outline-success mr-2"> LOGIN</Link>
   <Link to="/signup"  className="btn btn-outline-success">SIGN UP </Link> 
    </form>
  </div>
</nav> 
    )
}
