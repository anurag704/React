import React from 'react';
import {Link} from 'react-router-dom';

export default function Admin() {
    return (
         <>
  <nav className="navbar navbar-light" >
  <div className="container-fluid">
    <h1 className="navbar-brand">TechnoGiants</h1>
    <form className="d-flex">
   <Link to="/contact" className="btn btn-outline-success mr-2"> Contact </Link>
   <Link to='/logout' className="btn btn-outline-success ">Logout</Link>
    </form>
  </div>
</nav> 
        <h1>This is Admin Page.Only Authorized people can see this.</h1>
        <Link to='/logout'>Logout</Link>
       </>
    )
}
