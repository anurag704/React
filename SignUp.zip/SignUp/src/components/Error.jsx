import React from 'react';
import {Link} from 'react-router-dom';

const Error = () =>{
    return (
    <>
    <h1> OOps page not found !</h1>
    <Link to="/">Go Back To Login Page</Link>
    </>
    )
}

export default Error;