import React,{useState} from 'react';
import Navbar from '../Navbar';
import { Link} from 'react-router-dom';



export default function Login() {

  const [username,setUsername] = useState("");
  const [password,setPassword] = useState("");


  const handleSubmit = (event) => {
    event.preventDefault();
    alert(`username: ${username}, password: ${password}`);
  };

return (
    <>
    <Navbar />
      <section className="container-fluid login">
    <section className="row justify-content-center">
      <section className="col-12 col-sm-6 col-md-4">

        <form className="form-container" onSubmit={handleSubmit}>

        <div className="form-group">
          <h4 className="text-center font-weight-bold"> Login </h4>
          <label htmlFor="username">Username</label>
           <input type="text"
            className="form-control"
            placeholder="Enter username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input type="password"
           className="form-control"
          placeholder="enter a Password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
           />
        </div>
        <button type="submit" className="btn btn-primary btn-block">Submit</button>
        <div className="form-footer">
          <p> Don't have an account?
          <Link to="/signup"> Sign Up </Link> 
          </p>
        </div>
        </form>
      </section>
    </section>
  </section>
   </>
    )
}
