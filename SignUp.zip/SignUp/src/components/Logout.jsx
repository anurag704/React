import React from 'react';
import {Link} from 'react-router-dom';

export default function Logout() {
    return (
        <>
          <nav className="navbar navbar-light" >
  <div className="container-fluid">
    <h1 className="navbar-brand">TechnoGiants</h1>
    <form className="d-flex">
   <Link to="/" className="btn btn-outline-success mr-2">Login</Link>
    </form>
  </div>
</nav> 

        <h1>You have been logged out</h1>
        <Link to='/'>Login Again</Link>
        </>
    )
}
