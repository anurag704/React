import React,{useEffect, useState} from 'react';
import Navbar from '../Navbar';
import useLocalStorage from '../useLocalStorage';
import { Link} from 'react-router-dom';


export default function Signup() {

  const [data,setData] = useState({
    email: '',
    username: '',
    mobile: '',
    address : '',
    password: ''
    
  });
  


  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`form submitted`);
    console.log(data);
  };

  const onChange = (e) => {
    setData({
      ...data ,
       [e.target.name]:e.target.value 
    })
}

  useEffect(() => {
  useLocalStorage[key,data]

  },[data])

    return (
        <>
            <Navbar />

    <section className="container-fluid">
    <section className="row justify-content-center">
      <section className="col-12 col-sm-6 col-md-4">
        <form className="form-container" onSubmit={handleSubmit}>
        <div className="form-group">
          <h4 className="text-center font-weight-bold"> Sign Up </h4>
          <label >Email Address</label>
           <input type="email"
            className="form-control"
             placeholder="Enter email"
             name="email"
             value={data.email}
             onChange={onChange}
           />
        </div>
        <div className="form-group">
          <label>Username</label>
           <input type="text"
            className="form-control"
            placeholder="Enter username"
            name="username"
            value={data.username}
            onChange={onChange}
           />
        </div>
        <div className="form-group">
          <label>Mobile No.</label>
           <input type="number"
            className="form-control"
             placeholder="Enter phone no."
             name="mobile"
             value={data.mobile}
             onChange={onChange}
           />
        </div>
        <div className="form-group">
          <label>Address</label>
           <input type="text"
            className="form-control"
              placeholder="Enter address"
              name="address"
              value={data.address}
              onChange={onChange}  
              />
        </div>
        <div className="form-group">
          <label >Password</label>
          <input type="password"
           className="form-control"
            placeholder="Password"
            name="password"
            value={data.password}
            onChange={onChange}
            />
        </div>
        <button type="submit" className="btn btn-primary btn-block">Submit</button>
        <div className="form-footer">
          <p> Already have an account?
          <Link to="/"> Login </Link> 
          </p>
        </div>
        </form>
      </section>
    </section>
  </section>

        </>
    )
}
