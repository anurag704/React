const Sdata = [
{
    imgsrc :"https://wallpapercave.com/wp/wp4056399.jpg",
    title : " A Netflix Original Series",
    sname : "DARK",
    link :"https://www.netflix.com/in/title/80100172",
},
  {
    imgsrc:"https://wallpapercave.com/wp/wp6157145.jpg",
    title:" A Netflix Original Series",
    sname :"EXTRACTION",
    link :"https://www.netflix.com/in/title/80230399",
    
}
 ,{
    imgsrc :"https://wallpapercave.com/wp/wp1839578.jpg",
    title :" A Netflix Original Series",
    sname :"Stranger Things",
    link :"https://www.netflix.com/in/title/80057281",
    
}
 ,{
imgsrc:"https://wallpapercave.com/wp/wp4611463.png",
title:" A Netflix Original Series",
sname :"My First First Love",
link :"https://www.netflix.com/in/title/81026700",
}
 , {
imgsrc:"https://wallpapercave.com/wp/wp1957870.jpg",
title:" A Netflix Original Series",
sname :"The Vampire Diaries ",
link :"https://www.netflix.com/in/title/70143860",
},  ] ;

export default Sdata;
