import React from 'react';
import ReactDOM from 'react-dom';
import Card from "./Card"
import "./index.css";
import Sdata from './Sdata';

function ncard(val){
return(
   <Card 
   imgsrc={val.imgsrc}
   title={val.title}
   sname ={val.sname}
   link={val.link}
   />     
);
}

/*render method ka andar jsx then use curly brace */
/*Jsx ka andar js use karna ha then use curly brace */

ReactDOM.render( 
<>
<h1 className="heading_style">List of top 5 Netflix Series </h1>;

{Sdata.map(ncard)}
</>,
   document.getElementById("root")
);