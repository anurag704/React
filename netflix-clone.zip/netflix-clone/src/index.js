import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';


ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

serviceWorker.unregister();

//b7e322aec1ff420126c1b575d87c6986

//https://api.themoviedb.org/3/movie/550?api_key=b7e322aec1ff420126c1b575d87c6986